// Vector.java

public class Vector
{
    int a, b; // i and j coordinates
    
    public Vector( int a, int b )
    {
        this.a = a;
        this.b = b;
    }
}

